package tn.Enicarthage.ENTITIES;

public enum Etat {
    PAYER,
    NON_PAYER
}
