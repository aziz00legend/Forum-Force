package tn.Enicarthage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp7SpringBootDataWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
